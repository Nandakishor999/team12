---
name: Lumina AI (Dark Premium)
colors:
  surface: '#0b1326'
  surface-dim: '#0b1326'
  surface-bright: '#31394d'
  surface-container-lowest: '#060e20'
  surface-container-low: '#131b2e'
  surface-container: '#171f33'
  surface-container-high: '#222a3d'
  surface-container-highest: '#2d3449'
  on-surface: '#dae2fd'
  on-surface-variant: '#c7c4d7'
  inverse-surface: '#dae2fd'
  inverse-on-surface: '#283044'
  outline: '#908fa0'
  outline-variant: '#464554'
  surface-tint: '#c0c1ff'
  primary: '#c0c1ff'
  on-primary: '#1000a9'
  primary-container: '#8083ff'
  on-primary-container: '#0d0096'
  inverse-primary: '#494bd6'
  secondary: '#ddb7ff'
  on-secondary: '#490080'
  secondary-container: '#6f00be'
  on-secondary-container: '#d6a9ff'
  tertiary: '#3cddc7'
  on-tertiary: '#003731'
  tertiary-container: '#008678'
  on-tertiary-container: '#000705'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#e1e0ff'
  primary-fixed-dim: '#c0c1ff'
  on-primary-fixed: '#07006c'
  on-primary-fixed-variant: '#2f2ebe'
  secondary-fixed: '#f0dbff'
  secondary-fixed-dim: '#ddb7ff'
  on-secondary-fixed: '#2c0051'
  on-secondary-fixed-variant: '#6900b3'
  tertiary-fixed: '#62fae3'
  tertiary-fixed-dim: '#3cddc7'
  on-tertiary-fixed: '#00201c'
  on-tertiary-fixed-variant: '#005047'
  background: '#0b1326'
  on-background: '#dae2fd'
  surface-variant: '#2d3449'
typography:
  display-lg:
    fontFamily: Sora
    fontSize: 48px
    fontWeight: '700'
    lineHeight: '1.1'
    letterSpacing: -0.02em
  display-lg-mobile:
    fontFamily: Sora
    fontSize: 32px
    fontWeight: '700'
    lineHeight: '1.2'
    letterSpacing: -0.02em
  headline-md:
    fontFamily: Sora
    fontSize: 24px
    fontWeight: '600'
    lineHeight: '1.3'
  body-lg:
    fontFamily: Inter
    fontSize: 18px
    fontWeight: '400'
    lineHeight: '1.6'
  body-md:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: '1.6'
  label-sm:
    fontFamily: Geist
    fontSize: 12px
    fontWeight: '500'
    lineHeight: '1'
    letterSpacing: 0.05em
  mono-code:
    fontFamily: Geist
    fontSize: 14px
    fontWeight: '400'
    lineHeight: '1.5'
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  unit: 8px
  container-max-width: 1280px
  gutter: 24px
  margin-mobile: 16px
  margin-desktop: 40px
---

## Brand & Style

The brand personality is high-end, intelligent, and ethereal. It targets a sophisticated audience that values both cutting-edge technology and refined aesthetics. The emotional response should be one of "commanding calm"—the feeling of navigating a powerful, silent engine of intelligence.

This design system utilizes a **Glassmorphic** and **Modern Corporate** hybrid style. It relies on deep spatial depth created through layered translucency, ultra-fine iridescent borders, and vibrant light-source blurs that mimic the behavior of light passing through dense crystalline structures. The aesthetic is "Premium Technical," where every pixel feels intentional and high-value.

## Colors

The foundation of the palette is a "Void" blue-black (#020617) for deep backgrounds, moving into "Deep Charcoal" (#0f172a) for primary surface containers. 

The accent palette is built on **Indigo** and **Violet**, which are used to signify intelligence and action. A **Tertiary Teal** is used sparingly for success states and technical data highlights. 

To maintain high contrast:
- All primary text must be `rgba(255, 255, 255, 0.95)`.
- Secondary/Subtle text must not drop below `rgba(255, 255, 255, 0.60)`.
- Interactive states should utilize subtle glow effects (box-shadows with 20% opacity of the accent color) rather than significantly lightening the surface color.

## Typography

The typography system pairs the geometric, futuristic character of **Sora** for headlines with the extreme legibility and systematic feel of **Inter** for body copy. For technical data and UI labels, **Geist** provides a developer-friendly, precise aesthetic.

**Contrast Strategy:** On dark backgrounds, font weights are slightly increased (e.g., using 400 instead of 300) to compensate for the "thinning" effect of light text on dark surfaces. Headlines often utilize a subtle linear gradient from white to a very light silver to enhance the premium, metallic feel.

## Layout & Spacing

The design system employs a **Fixed Grid** on desktop (12 columns) and a **Fluid Grid** on mobile (4 columns). The spacing rhythm is strictly based on an **8px base unit**, ensuring mathematical harmony across all components.

Layouts should favor generous whitespace (or "dark space") to prevent the UI from feeling claustrophobic. Use 40px - 64px padding for major section containers to allow the glassmorphic layers room to "breathe" against the background.

## Elevation & Depth

Depth is conveyed through **Tonal Layering** and **Glassmorphism**:

1.  **Level 0 (Base):** Deepest background (#020617).
2.  **Level 1 (Card/Container):** Charcoal (#0f172a) with a 1px solid border at 10% white opacity.
3.  **Level 2 (Floating/Interactive):** Translucent glass (Background blur 20px) with a 1px iridescent border—a linear gradient border spanning from Indigo to Violet at 30% opacity.
4.  **Shadows:** Shadows are not black; they are ultra-diffused Navy (#020617) with large radii (30px+) and low opacity (40%), used to lift glass panels off the base layer.

## Shapes

The shape language is **Rounded**, using 0.5rem (8px) as the standard radius. This balances the technical precision of the brand with an approachable, modern feel. Large containers (cards) should use `rounded-xl` (24px) to emphasize the soft, premium nature of the glass panels.

## Components

### Buttons
- **Primary:** Solid Indigo-to-Violet gradient. Text is white. Subtle outer glow on hover.
- **Secondary:** Glass background with 1px white border (15% opacity).
- **Tertiary:** Ghost style, white text, Geist font for a technical look.

### Input Fields
Inputs should have a dark, recessed background (slightly darker than the card surface) with a 1px border. Upon focus, the border should animate to the primary Indigo color with a 4px soft outer glow.

### Chips / Badges
Small, pill-shaped elements with a low-opacity Indigo background (15%) and high-opacity Indigo text. Use Geist for the font to maintain the technical aesthetic.

### Cards
Cards are the primary expression of the design system. They feature a `backdrop-filter: blur(12px)`, a subtle inner glow (top-left) to simulate a light source, and an iridescent 1px stroke.

### AI Indicators
Any AI-generated content or interactive AI elements should feature the "Iridescent Highlight"—a moving linear gradient that transitions through Indigo, Violet, and Teal.